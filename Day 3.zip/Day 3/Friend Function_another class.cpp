#include <iostream>
using namespace std;
class B;
class A{

public:

        int height, length, width;

        void setInput(int h, int l, int w) {

            height = h;
            length = l;
            width = w;
        }
friend int volume(A, B);
};
class B{

public:

        int height, length, width;

        void setInput(int h, int l, int w) {

            height = h;
            length = l;
            width = w;
        }
friend int volume(A, B);
};
int volume(A obj1,B obj2){
    return (obj1.height*obj1.width*obj1.length)+(obj2.height*obj2.width*obj2.length) ;
}
int main()
{
  A obj1;
  B obj2;
    obj1.setInput(2,4,8);
    obj2.setInput(3,6,9);

  cout<<"Total Volume: "<<volume(obj1, obj2);

    return 0;
}
