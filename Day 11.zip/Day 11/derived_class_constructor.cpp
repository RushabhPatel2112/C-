#include <iostream>
using namespace std;

class A
{
 	
 	int x;
 	public:
 	A(){
 	    cout<<"\nBase default constructor";
 	}
};
class B : public A
{
 	int y;
 	public:
 	B()      
 	{
 	   cout<<"\nDerived default constructor";
 	}
 	B(int i){
 	    cout<<"\nDerived parameterized constructor";
 	}
};

int main()
{
    A ob1;          
 	B ob2;
 	B ob3(10);
 	return 0;
}            
