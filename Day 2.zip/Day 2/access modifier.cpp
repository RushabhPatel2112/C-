#include<iostream>
using namespace std;

class sq{

	private:
		int r;

	public:
		void multiply(int x)
		{
			r= x;

			int s = r*r;

			cout << "Input is: " << r << endl;
			cout << "Square is: " << s;
		}

};

int main()
{

	sq obj;

	obj.multiply(5);


	return 0;
}
