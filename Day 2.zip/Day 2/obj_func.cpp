#include <iostream>
using namespace std;
class sum{
    public:
      int a,b;
       void setInput (int x, int y) {
        a= x;
        b= y;
       }
        sum add (sum objl, sum obj2){
              sum obj3;
              obj3.a = objl.a + obj2.a;
              obj3.b = objl.b + obj2.b;
              return obj3;
        }
} ;
int main (){
    sum obj1, obj2, obj3;
    obj1.setInput (10,2);
    obj2.setInput (15,5);
    obj3 = obj1.add (obj1, obj2);
    cout << "Result:\n " << obj3.a << "\n " << obj3.b;
return 0;
}
