
#include <iostream>

using namespace std;

class person{
  int weight=70;
  void weight1(){
      weight=70;
  }
  
  public:
    int age;
    person( ){
         age=21;
        
    }
    void age1()
    {
        cout<<"Age is:"<<age<<endl;
    }
    /* void height(){
        cout<<"Height is:"<<height<<endl;
    }*/
};

class doctor: public person
{
    public:
        int height;
        void disp(){
            height =170;
            cout<<"height is: "<<height<<endl;
        }

    void priv(){
        cout<<"weight is:"<<weight<<endl;
    }
};



int main()
{
    doctor d;
    d.disp();
    d.age1();
    d.priv();
    return 0;
}

