#include <iostream>

using namespace std;

class Person {

    private:
        int a;

    public:
        void displayPublicPerson() {
            cout << "inside displayPublicPerson" << endl;
        }
};

class Student: public Person {

    private:
        int b;

    public:
        void displayPublicStudent() {
            cout << "inside displayPublicStudent" << endl;
        }
};

class ITStudent: public Student {

    private:
        int c;

    public:
        void displayPublicITStudent() {
            cout << "inside displayPublicITStudent" << endl;
        }
};

int main()
{
    Person p1;
    Student s1;
    ITStudent it1;

    p1.displayPublicPerson();
    s1.displayPublicPerson();
    s1.displayPublicStudent();
    it1.displayPublicPerson();
    it1.displayPublicStudent();
    it1.displayPublicITStudent();       

    return 0;
}
