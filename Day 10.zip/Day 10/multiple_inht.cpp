
#include <iostream>

using namespace std;

class person{
 
  public:
    int age=21;
    person(){
         age=21;
        cout<<"Age is: "<<age<<endl;
    }
    void age1()
    {
        cout<<"Age is:"<<age<<endl;
    }
    /* void height(){
        cout<<"Height is:"<<height<<endl;
    }*/
};

class doctor
{
    public:
        int height=170;
        void disp(){
            height =170;
            cout<<"Height is : "<<height<<endl;
        }
};
class doctor2: public doctor, public person
{
    public:
        int add=0;
        void disp_sum(){
            add=height+age;
            cout<<add<<endl;
        }
};

int main()
{
    doctor d;
    person p1;
    doctor2 d2;
    d.disp();
    d2.disp_sum();
    return 0;
}

