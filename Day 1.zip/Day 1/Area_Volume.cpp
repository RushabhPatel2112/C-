#include <iostream>
using namespace std;

class Measure {

public:

        int height, length, width;

        void setInput(int h, int l, int w) {

            height = h;
            length = l;
            width = w;
        }

        int area(){
            return width*length;
          }

        int volume(){
            return height*width*length;
        }

};

int main()
{
    Measure obj1, obj2;

    obj1.setInput(2,4,8);
    obj2.setInput(3,6,9);

    cout << "Area of object 1: " << obj1.area() << "\n" << "Volume of object 1: " << obj1.volume();
    cout << "\nArea of object 2: " << obj2.area() << "\n" << "Volume of object 2: " << obj2.volume();
    return 0;
}
