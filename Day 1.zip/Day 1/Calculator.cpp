#include <iostream>

using namespace std;
class Calculator {
    public:
        int ip1,ip2;
        void set(int a, int b) {
        ip1 = a;
        ip2 = b;
        }
        int add() {
        return ip1+ip2;
        }

        int subtract() {
        return ip1-ip2;
        }

        int multiply() {
        return ip1*ip2;
        }

        int divide() {
        return ip1/ip2;
        }

        int mod() {
        return ip1%ip2;
        }

        int average() {
        return (ip1+ip2)/2;
        }
};
int main () {
    Calculator obj1;
    int inp;
    obj1.set(21,3);
    cout << "The inputs: " << obj1.ip1 << " " << obj1.ip2 << endl;

    cout << "Enter 1 for Addition\nEnter 2 for Substraction\nEnter 3 for Multiplication\nEnter 4 for Division\nEnter 5 for modulo division\nEnter 6 for average\n";
    cin >> inp;

    switch(inp) {
        case 1: {
            cout << "The sum is: " << obj1.add();
            }
        break;

        case 2: {
            cout << "The difference is: " << obj1.subtract();
            }
        break;

        case 3: {
            cout << "The product is: " << obj1.multiply();
            }
        break;

        case 4: {
            cout << "The result of division is: " << obj1.divide();
            }
        break;

        case 5: {
            cout << "The result of modulo division is: " << obj1.mod();
            }
        break;

        case 6: {
            cout << "The average is: " << obj1.average();
            }
        break;

        default: cout << "Enter valid input";
        break;
    }

    return 0;
}
