#include<iostream>
using namespace std;

inline void sum(int num1,int num2) {

    cout<<num1 + num2 << "\n";

}

int main() {

    sum(10, 20);

    sum(100, 400);

    return 0;

}
