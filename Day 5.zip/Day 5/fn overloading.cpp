#include<iostream>
using namespace std;
int mul(int,int);
float mul(float,int);


int mul(int a,int b)
{
    return a*b;
}
float mul(double x, int y)
{
    return x*y;
}
int main()
{
    int fn1 = mul(21,12);
    float fn2 = mul(0.73,3.9);
    cout << "fn1 is : " <<fn1<<endl;
    cout <<"fn2 is : "  <<fn2<<endl;
    return 0;
}
