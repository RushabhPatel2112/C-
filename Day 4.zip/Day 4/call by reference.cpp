#include<iostream>
using namespace std;
void swap(int *x, int *y)
{
 int swap;
 swap=*x;
 *x=*y;
 *y=swap;
}
int main()
{
 int x=500, y=100;
 cout<<"Value of x (Before): "<<x<<endl;
 cout<<"Value of y (BeforE): "<<y<<endl;
 swap(&x, &y);
 cout<<"Value of x (after): "<<x<<endl;
 cout<<"Value of y (After): "<<y<<endl;
 return 0;  
}
