#include <iostream>
using namespace std;

void init(int &a, int &b, char &c)
{
    a = 10;
    b = 20;
    c = 'A';
}

int main()
{
    int a, b;
    char c;

    init(a, b, c);
    cout << "a = " << a << ", b = " << b << ", c = " << c;

    return 0;
}
