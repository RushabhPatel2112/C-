#include<iostream>
using namespace std;

class A{
private:
    int i=10;
public:

A(){
cout<<"Inside the constructor "<<endl<<endl;
}
A(A &obj){
cout<<"Inside the Copy Constructor "<<endl<<endl;
}
void add(A obj1, A obj2){
cout<<"Inside the add() function "<<endl<<endl;
}

};

int main(){
    A obj1,obj2;
    obj1.add(obj1,obj2);

return 0;
}
